package service;


import java.util.ArrayList;

import java.util.List;



import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


import ejb.*;

@Stateless
@Path("/admin")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)

public class AdminService  
{

	
	@PersistenceContext(unitName = "hello")
	private EntityManager entityManager;
	//@EJB
	Admin admin ;
	boolean flag=false;
	
	@GET
	//@Path("/hello")
	public String sayHello() {
		return "hello";
	}

	@POST
	@Path("/register")
	public String RegisterAdmin(Admin admin) 
	{
		entityManager.persist(admin);
		return "Successfully Registered";
	}
	
	@GET
	@Path("/getByID/{id}")
	public Admin findAdminByID(@PathParam("id") int id) {
		
		return entityManager.find(Admin.class, id);
	}
	
}


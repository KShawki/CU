package ejb;

import java.io.Serializable;

import javax.ejb.Stateless;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@Stateless
@Entity

public class Admin
{
	//private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int AdminId ;
   public String AdminName;
   public String AdminPassword ;
   public String role ;
   public void setRole(String role) 
   {
	this.role = role;
    }
    public String getRole() {
	 return role;
    }
	public String getAdminName() {
		return AdminName;
	}
	
	public void setAdminName(String AName) {
		this.AdminName = AName;
	}
	@Id
	public int getAdminId() {
		return AdminId;
	}
	public void setAdminId(int Aid) {
		this.AdminId = Aid;
	}
	public String getAdminPassword() {
		return AdminPassword;
	}
	public void setAdminPassword(String password) {
		AdminPassword = password;
	}

   
}

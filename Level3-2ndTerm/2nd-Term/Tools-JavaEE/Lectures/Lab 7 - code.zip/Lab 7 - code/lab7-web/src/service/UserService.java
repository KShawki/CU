package service;

import java.util.ArrayList;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import ejbs.User;

@Stateless
@Path("/users")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class UserService {
	
	@EJB
	User user;
	
	ArrayList<User> users = new ArrayList<User>();
	
	@GET
	@Path("hello")
	public String sayHello() {
		return user.getMsg();
	}
	
	@GET
	@Path("hello_id/{id}")
	public String sayHello_id(@PathParam("id")int id) {
		return user.getMsg() + " " + id;
	}
	
	@POST
	@Path("adduser")
	public String addUser(User u) {
		users.add(u);
		return "user added successfully";
	}
	
	
	
	

}

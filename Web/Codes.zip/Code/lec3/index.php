<form action="login_check.php" method="post">
email<br>
<input type="text" name="email" id="email" style="width:320px" required>
<br>

password<br>
<input type="password" name="password" id="password" style="width:320px" required>
<br>

<input type="submit" name="btn" id="btn" value="Login">

</form>
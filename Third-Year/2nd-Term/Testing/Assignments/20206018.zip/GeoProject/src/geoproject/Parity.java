package geoproject;

/**
 * Even or Odd.
 * 
 * @author dave
 * 
 */
public enum Parity {
    EVEN, ODD;
}

# Problem Statemnet:

- Write a 32-bits intel-syntax assembly program that can be
  compiled in the same way the 32-bits lab samples are compiled.
- The program should take the following inputs from the user:
- An integer n.
- n floating point numbers (Use the "double" type).
- The program should output (1+1/1)+(2+1/4)+(3+1/9)+(4+1/16)+...+(n+1/(n^2)).
